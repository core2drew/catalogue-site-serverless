import express, { NextFunction, Request, Response } from "express";
import getProductList from "./list";

const router = express.Router();

router.use((_req: Request, _res: Response, next: NextFunction) => {
  next();
});

router.get("/", getProductList);

export default router;
